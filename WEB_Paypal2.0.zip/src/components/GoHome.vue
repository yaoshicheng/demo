<template>
  <div class="homeBtn" @click="goHome">
    X
  </div>
</template>

<script>
  export default {
    name: 'GoHome',
    data () {
      return {
        currentTime:"",
      }
    },
    mounted() {
    },
    updated(){
    },
    methods: {
      goHome(){
        this.$router.push("/")
      },
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
  @import '../css/common';
</style>
